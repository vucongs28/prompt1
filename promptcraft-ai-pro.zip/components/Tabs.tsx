
import React from 'react';
import { TabName } from '../types';
import { TABS } from '../constants';

interface TabsProps {
  activeTab: TabName;
  setActiveTab: (tab: TabName) => void;
}

const Tabs: React.FC<TabsProps> = ({ activeTab, setActiveTab }) => {
  return (
    <div className="flex justify-center border-b border-gray-700">
      <div className="flex space-x-2 md:space-x-4">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-3 text-sm md:text-base font-medium transition-colors duration-300 ease-in-out focus:outline-none ${
              activeTab === tab.id
                ? 'border-b-2 border-purple-500 text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>
    </div>
  );
};

export default Tabs;
