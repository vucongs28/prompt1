import React, { useState, useRef, useCallback, useEffect } from 'react';
import { generateSpeech } from '../services/geminiService';
import Button from './common/Button';
import Select from './common/Select';
import Loader from './common/Loader';
import { DownloadIcon, PlayIcon, SparklesIcon, TrashIcon } from '../constants';
import { TTS_VOICES } from '../constants';

// Helper to decode base64
function decode(base64: string) {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
}

// AudioBuffer to WAV conversion
const audioBufferToWav = (buffer: AudioBuffer): Blob => {
    const numOfChan = buffer.numberOfChannels;
    const length = buffer.length * numOfChan * 2 + 44;
    const bufferArr = new ArrayBuffer(length);
    const view = new DataView(bufferArr);
    const channels = [];
    let i, sample;
    let offset = 0;
    let pos = 0;

    const setUint16 = (data: number) => {
        view.setUint16(pos, data, true);
        pos += 2;
    };
    const setUint32 = (data: number) => {
        view.setUint32(pos, data, true);
        pos += 4;
    };

    setUint32(0x46464952); // "RIFF"
    setUint32(length - 8); // file length - 8
    setUint32(0x45564157); // "WAVE"
    setUint32(0x20746d66); // "fmt " chunk
    setUint32(16); // length of fmt data
    setUint16(1); // PCM - integer samples
    setUint16(numOfChan); // two channels
    setUint32(buffer.sampleRate); // sample rate
    setUint32(buffer.sampleRate * 2 * numOfChan); // byte rate
    setUint16(numOfChan * 2); // block align
    setUint16(16); // bits per sample
    setUint32(0x61746164); // "data" - chunk
    setUint32(length - pos - 4); // chunk length

    for (i = 0; i < buffer.numberOfChannels; i++)
        channels.push(buffer.getChannelData(i));

    while (pos < length) {
        for (i = 0; i < numOfChan; i++) {
            sample = Math.max(-1, Math.min(1, channels[i][offset]));
            sample = (0.5 + sample < 0 ? sample * 32768 : sample * 32767) | 0;
            view.setInt16(pos, sample, true);
            pos += 2;
        }
        offset++;
    }

    return new Blob([view], { type: 'audio/wav' });
};

const TTS_HISTORY_KEY = 'promptCraft-ttsHistory';

const TextToSpeechStudio: React.FC = () => {
    const [text, setText] = useState('');
    const [voice, setVoice] = useState(TTS_VOICES[0].id);
    const [isLoading, setIsLoading] = useState(false);
    const [audioUrl, setAudioUrl] = useState<string | null>(null);
    const audioRef = useRef<HTMLAudioElement>(null);
    const audioContextRef = useRef<AudioContext | null>(null);
    const [history, setHistory] = useState<string[]>(() => {
        try {
            const savedHistory = localStorage.getItem(TTS_HISTORY_KEY);
            return savedHistory ? JSON.parse(savedHistory) : [];
        } catch (error) {
            console.error("Failed to parse TTS history:", error);
            return [];
        }
    });

    useEffect(() => {
        if (audioUrl && !isLoading && text && !history.includes(text)) {
            const newHistory = [text, ...history].slice(0, 20);
            setHistory(newHistory);
            localStorage.setItem(TTS_HISTORY_KEY, JSON.stringify(newHistory));
        }
    }, [audioUrl, isLoading, text]);

    const getAudioContext = useCallback(() => {
        if (!audioContextRef.current) {
            audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        }
        return audioContextRef.current;
    }, []);

    const handleGenerate = async () => {
        if (!text.trim()) return;
        setIsLoading(true);
        setAudioUrl(null);

        try {
            const base64Audio = await generateSpeech(text, voice);
            const audioData = decode(base64Audio);
            const ctx = getAudioContext();

            const dataInt16 = new Int16Array(audioData.buffer);
            const frameCount = dataInt16.length;
            const buffer = ctx.createBuffer(1, frameCount, 24000);
            const channelData = buffer.getChannelData(0);
            for (let i = 0; i < frameCount; i++) {
                channelData[i] = dataInt16[i] / 32768.0;
            }

            const wavBlob = audioBufferToWav(buffer);
            const url = URL.createObjectURL(wavBlob);
            setAudioUrl(url);

        } catch (error) {
            console.error(error);
            alert("Tạo âm thanh thất bại. Vui lòng thử lại.");
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleDownload = () => {
        if (!audioUrl) return;
        const a = document.createElement("a");
        a.href = audioUrl;
        a.download = "promptcraft-ai-voice.wav";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    };

    const clearHistory = () => {
        setHistory([]);
        localStorage.removeItem(TTS_HISTORY_KEY);
    };

    return (
        <>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="flex flex-col space-y-6">
                    <h2 className="text-2xl font-bold text-white">Chuyển văn bản thành giọng nói tự nhiên</h2>
                    <div>
                        <label htmlFor="tts-text" className="block text-sm font-medium text-gray-300 mb-2">Kịch bản hoặc văn bản của bạn</label>
                        <textarea
                            id="tts-text"
                            value={text}
                            onChange={(e) => setText(e.target.value)}
                            placeholder="Nhập văn bản bạn muốn chuyển thành giọng nói..."
                            className="w-full bg-gray-700 border border-gray-600 text-white rounded-lg p-3 h-40 focus:ring-purple-500 focus:border-purple-500 transition"
                        />
                    </div>
                     <Select
                        label="Chọn một giọng nói"
                        options={TTS_VOICES.map(v => ({ value: v.id, label: v.name }))}
                        value={voice}
                        onChange={(e) => setVoice(e.target.value)}
                    />
                    <Button onClick={handleGenerate} isLoading={isLoading} disabled={isLoading || !text}>
                       <SparklesIcon /> Tạo giọng nói
                    </Button>
                </div>
                <div className="bg-gray-900/50 rounded-lg p-6 flex flex-col justify-center items-center min-h-[300px]">
                    <h3 className="text-xl font-semibold mb-4 text-gray-200">Âm thanh đầu ra</h3>
                    {isLoading && <Loader />}
                    {!isLoading && audioUrl && (
                        <div className="w-full flex flex-col items-center space-y-6">
                            <audio ref={audioRef} src={audioUrl} controls className="w-full"></audio>
                            <div className="flex space-x-4">
                                <Button variant="secondary" onClick={() => audioRef.current?.play()}>
                                    <PlayIcon/> Phát
                                </Button>
                                <Button variant="secondary" onClick={handleDownload}>
                                    <DownloadIcon/> Tải xuống
                                </Button>
                            </div>
                        </div>
                    )}
                     {!isLoading && !audioUrl && (
                        <div className="text-gray-500 text-center">
                            <p>Âm thanh được tạo sẽ xuất hiện ở đây.</p>
                            <p className="text-sm mt-2">Sẵn sàng để phát và tải xuống.</p>
                        </div>
                    )}
                </div>
            </div>
            <div className="mt-8 pt-6 border-t border-gray-700">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-semibold text-gray-200">Lịch sử</h3>
                    {history.length > 0 && (
                        <button onClick={clearHistory} className="text-sm text-purple-400 hover:text-purple-300 flex items-center gap-1">
                            <TrashIcon /> Xóa lịch sử
                        </button>
                    )}
                </div>
                {history.length > 0 ? (
                    <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
                        {history.map((item, index) => (
                            <div key={index} onClick={() => setText(item)} className="bg-gray-700 p-3 rounded-lg cursor-pointer hover:bg-gray-600 transition">
                                <p className="text-gray-300 truncate">{item}</p>
                            </div>
                        ))}
                    </div>
                ) : (
                    <p className="text-gray-500">Chưa có văn bản nào được chuyển đổi.</p>
                )}
            </div>
        </>
    );
};

export default TextToSpeechStudio;