import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="text-center mb-10">
      <h1 className="text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600">
        PromptCraft AI
      </h1>
      <p className="mt-2 text-lg text-gray-400">
        “Từ ý tưởng đến giọng nói — Tất cả trong một cỗ máy sáng tạo.”
      </p>
    </header>
  );
};

export default Header;