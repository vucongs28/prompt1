import React, { useState, useEffect } from 'react';
import { optimizePrompt } from '../services/geminiService';
import Button from './common/Button';
import Select from './common/Select';
import Loader from './common/Loader';
import { CopyIcon, SparklesIcon, TrashIcon } from '../constants';
import { PROMPT_TEMPLATES, TARGET_MODELS } from '../constants';

type HistoryItem = { original: string; optimized: string };
const OPTIMIZER_HISTORY_KEY = 'promptCraft-optimizerHistory';


const PromptOptimizer: React.FC = () => {
    const [originalPrompt, setOriginalPrompt] = useState('');
    const [targetModel, setTargetModel] = useState(TARGET_MODELS[0]);
    const [optimizedPrompt, setOptimizedPrompt] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [copyButtonText, setCopyButtonText] = useState('Sao chép câu lệnh');
    const [history, setHistory] = useState<HistoryItem[]>(() => {
        try {
            const savedHistory = localStorage.getItem(OPTIMIZER_HISTORY_KEY);
            return savedHistory ? JSON.parse(savedHistory) : [];
        } catch (error) {
            console.error("Failed to parse optimizer history:", error);
            return [];
        }
    });

    useEffect(() => {
        if (optimizedPrompt && !isLoading && originalPrompt) {
            if (!history.some(h => h.original === originalPrompt && h.optimized === optimizedPrompt)) {
                const newHistory = [{ original: originalPrompt, optimized: optimizedPrompt }, ...history].slice(0, 20);
                setHistory(newHistory);
                localStorage.setItem(OPTIMIZER_HISTORY_KEY, JSON.stringify(newHistory));
            }
        }
    }, [optimizedPrompt, isLoading, originalPrompt]);

    const handleOptimize = async () => {
        if (!originalPrompt.trim()) return;
        setIsLoading(true);
        setOptimizedPrompt('');
        try {
            const result = await optimizePrompt(originalPrompt, targetModel);
            setOptimizedPrompt(result);
        } catch (error) {
            console.error(error);
            setOptimizedPrompt("Đã xảy ra lỗi khi tối ưu hóa câu lệnh.");
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleCopy = () => {
        navigator.clipboard.writeText(optimizedPrompt);
        setCopyButtonText('Đã sao chép!');
        setTimeout(() => setCopyButtonText('Sao chép câu lệnh'), 2000);
    };
    
    const clearHistory = () => {
        setHistory([]);
        localStorage.removeItem(OPTIMIZER_HISTORY_KEY);
    };

    const loadFromHistory = (item: HistoryItem) => {
        setOriginalPrompt(item.original);
        setOptimizedPrompt(item.optimized);
    };


    return (
        <div>
            <h2 className="text-2xl font-bold text-white mb-6">Tối ưu hóa câu lệnh AI của bạn</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                    <label htmlFor="original-prompt" className="block text-sm font-medium text-gray-300 mb-2">Câu lệnh của bạn</label>
                    <textarea
                        id="original-prompt"
                        value={originalPrompt}
                        onChange={(e) => setOriginalPrompt(e.target.value)}
                        placeholder="VD: tạo ảnh một cô gái trong rừng"
                        className="w-full bg-gray-700 border border-gray-600 text-white rounded-lg p-3 h-48 focus:ring-purple-500 focus:border-purple-500 transition"
                    />
                </div>
                <div className="bg-gray-900/50 rounded-lg p-4">
                     <h3 className="text-lg font-semibold mb-3 text-gray-200">Câu lệnh đã tối ưu</h3>
                     {isLoading ? <Loader /> : optimizedPrompt ? (
                         <div className="bg-gray-700 p-4 rounded-md h-48 overflow-y-auto text-gray-200">{optimizedPrompt}</div>
                     ) : (
                        <div className="flex items-center justify-center h-48 text-gray-500 bg-gray-700 rounded-md">Phiên bản tối ưu sẽ xuất hiện ở đây...</div>
                     )}
                </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-6">
                <Select label="Mô hình AI mục tiêu" options={TARGET_MODELS} value={targetModel} onChange={(e) => setTargetModel(e.target.value)} />
                <div className="flex items-end">
                    <Button onClick={handleOptimize} isLoading={isLoading} disabled={isLoading || !originalPrompt}>
                       <SparklesIcon /> Tối ưu hóa
                    </Button>
                </div>
            </div>
             {optimizedPrompt && !isLoading && (
                <Button onClick={handleCopy} variant="secondary" className="mt-4 md:w-1/2 mx-auto">
                    <CopyIcon /> {copyButtonText}
                </Button>
            )}
            <div className="mt-8 pt-6 border-t border-gray-700">
                <h3 className="text-lg font-semibold mb-3 text-gray-200">Thư viện mẫu câu lệnh</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                    {PROMPT_TEMPLATES.map(template => (
                        <button key={template.name} onClick={() => setOriginalPrompt(template.prompt)} className="bg-gray-700 hover:bg-gray-600 text-left text-sm p-3 rounded-lg transition h-full">
                            <p className="font-bold text-purple-400">{template.name}</p>
                            <p className="text-gray-400 text-xs mt-1 line-clamp-3">{template.prompt}</p>
                        </button>
                    ))}
                </div>
            </div>
            <div className="mt-8 pt-6 border-t border-gray-700">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-semibold text-gray-200">Lịch sử</h3>
                    {history.length > 0 && (
                        <button onClick={clearHistory} className="text-sm text-purple-400 hover:text-purple-300 flex items-center gap-1">
                           <TrashIcon /> Xóa lịch sử
                        </button>
                    )}
                </div>
                {history.length > 0 ? (
                    <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
                        {history.map((item, index) => (
                            <div key={index} onClick={() => loadFromHistory(item)} className="bg-gray-700 p-3 rounded-lg cursor-pointer hover:bg-gray-600 transition">
                                <p className="font-semibold text-gray-300 truncate">Gốc: {item.original}</p>
                                <p className="text-purple-400 truncate mt-1 text-sm">Tối ưu: {item.optimized}</p>
                            </div>
                        ))}
                    </div>
                ) : (
                    <p className="text-gray-500">Chưa có câu lệnh nào được tối ưu.</p>
                )}
            </div>
        </div>
    );
};

export default PromptOptimizer;