
import React from 'react';

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
    label: string;
    options: { value: string; label: string }[] | string[];
}

const Select: React.FC<SelectProps> = ({ label, options, ...props }) => {
    return (
        <div>
            <label htmlFor={props.id || props.name} className="block text-sm font-medium text-gray-300 mb-2">
                {label}
            </label>
            <select
                {...props}
                className="w-full bg-gray-700 border border-gray-600 text-white rounded-lg p-3 focus:ring-purple-500 focus:border-purple-500 transition"
            >
                {options.map((option) =>
                    typeof option === 'string' ? (
                        <option key={option} value={option}>{option}</option>
                    ) : (
                        <option key={option.value} value={option.value}>{option.label}</option>
                    )
                )}
            </select>
        </div>
    );
};

export default Select;
