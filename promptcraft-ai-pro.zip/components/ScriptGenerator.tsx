import React, { useState, useEffect } from 'react';
import { generateScript } from '../services/geminiService';
import Button from './common/Button';
import Loader from './common/Loader';
import Select from './common/Select';
import { DownloadIcon, SparklesIcon, TrashIcon, CopyIcon } from '../constants';
import { SCRIPT_TONES, SCRIPT_DURATIONS } from '../constants';

const SCRIPT_HISTORY_KEY = 'promptCraft-scriptHistory';

const ScriptGenerator: React.FC = () => {
    const [idea, setIdea] = useState('');
    const [duration, setDuration] = useState(SCRIPT_DURATIONS[0]);
    const [tone, setTone] = useState(SCRIPT_TONES[0]);
    const [audience, setAudience] = useState('');
    const [script, setScript] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [copyButtonText, setCopyButtonText] = useState('Sao chép');
    const [history, setHistory] = useState<string[]>(() => {
        try {
            const savedHistory = localStorage.getItem(SCRIPT_HISTORY_KEY);
            return savedHistory ? JSON.parse(savedHistory) : [];
        } catch (error) {
            console.error("Failed to parse script history:", error);
            return [];
        }
    });

    useEffect(() => {
        if (script && !isLoading && !history.includes(script)) {
            const newHistory = [script, ...history].slice(0, 20); // Keep latest 20
            setHistory(newHistory);
            localStorage.setItem(SCRIPT_HISTORY_KEY, JSON.stringify(newHistory));
        }
    }, [script, isLoading]);

    const handleGenerate = async () => {
        if (!idea.trim() || !audience.trim()) {
            alert("Vui lòng cung cấp ý tưởng và đối tượng khán giả.");
            return;
        }
        setIsLoading(true);
        setScript('');
        try {
            const result = await generateScript(idea, duration, tone, audience);
            setScript(result);
        } catch (error) {
            console.error(error);
            setScript("Đã xảy ra lỗi khi tạo kịch bản.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleCopy = () => {
        if (!script) return;
        const textToCopy = script.replace(/###\s/g, '').replace(/\*\*/g, '');
        navigator.clipboard.writeText(textToCopy);
        setCopyButtonText('Đã sao chép!');
        setTimeout(() => setCopyButtonText('Sao chép'), 2000);
    };

    const downloadTxtFile = () => {
        const element = document.createElement("a");
        const file = new Blob([script.replace(/###\s/g, '').replace(/\*\*/g, '')], { type: 'text/plain' });
        element.href = URL.createObjectURL(file);
        element.download = "ai-script.txt";
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);
    };

    const clearHistory = () => {
        setHistory([]);
        localStorage.removeItem(SCRIPT_HISTORY_KEY);
    };

    return (
        <>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="flex flex-col space-y-6">
                    <h2 className="text-2xl font-bold text-white">Tạo kịch bản từ ý tưởng của bạn</h2>
                    <div>
                        <label htmlFor="idea" className="block text-sm font-medium text-gray-300 mb-2">Ý tưởng Video của bạn</label>
                        <textarea
                            id="idea"
                            value={idea}
                            onChange={(e) => setIdea(e.target.value)}
                            placeholder="VD: Video về thói quen buổi sáng hiệu quả"
                            className="w-full bg-gray-700 border border-gray-600 text-white rounded-lg p-3 h-28 focus:ring-purple-500 focus:border-purple-500 transition"
                        />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <Select label="Thời lượng Video" options={SCRIPT_DURATIONS} value={duration} onChange={e => setDuration(e.target.value)} />
                        <Select label="Tông giọng" options={SCRIPT_TONES} value={tone} onChange={e => setTone(e.target.value)} />
                    </div>
                    <div>
                         <label htmlFor="audience" className="block text-sm font-medium text-gray-300 mb-2">Đối tượng khán giả</label>
                        <input
                            id="audience"
                            type="text"
                            value={audience}
                            onChange={(e) => setAudience(e.target.value)}
                            placeholder="VD: Chuyên gia trẻ, sinh viên"
                            className="w-full bg-gray-700 border border-gray-600 text-white rounded-lg p-3 focus:ring-purple-500 focus:border-purple-500 transition"
                        />
                    </div>
                    <Button onClick={handleGenerate} isLoading={isLoading} disabled={isLoading || !idea || !audience}>
                        <SparklesIcon /> Tạo kịch bản
                    </Button>
                </div>
                <div className="bg-gray-900/50 rounded-lg p-6 min-h-[300px]">
                    <h3 className="text-xl font-semibold mb-4 text-gray-200">Kịch bản đã tạo</h3>
                    {isLoading ? (
                        <Loader />
                    ) : script ? (
                        <>
                            <div className="prose prose-invert prose-sm max-w-none bg-gray-700 p-4 rounded-md h-96 overflow-y-auto" dangerouslySetInnerHTML={{ __html: script.replace(/### (.*?)\n/g, '<h3 class="text-purple-400 font-bold">$1</h3>').replace(/\n/g, '<br />') }}></div>
                             <div className="flex items-center gap-4 mt-4">
                                <Button onClick={handleCopy} variant="secondary" className="w-full">
                                    <CopyIcon /> {copyButtonText}
                                </Button>
                                <Button onClick={downloadTxtFile} variant="secondary" className="w-full">
                                   <DownloadIcon /> Tải về .txt
                                </Button>
                            </div>
                        </>
                    ) : (
                        <div className="flex items-center justify-center h-full text-gray-500">
                            Kịch bản của bạn sẽ xuất hiện ở đây...
                        </div>
                    )}
                </div>
            </div>
            <div className="mt-8 pt-6 border-t border-gray-700">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-semibold text-gray-200">Lịch sử</h3>
                    {history.length > 0 && (
                        <button onClick={clearHistory} className="text-sm text-purple-400 hover:text-purple-300 flex items-center gap-1">
                            <TrashIcon /> Xóa lịch sử
                        </button>
                    )}
                </div>
                {history.length > 0 ? (
                    <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
                        {history.map((item, index) => (
                            <div key={index} onClick={() => setScript(item)} className="bg-gray-700 p-3 rounded-lg cursor-pointer hover:bg-gray-600 transition">
                                <p className="text-gray-300 truncate">{item.split('\n')[0].replace(/###/g, '').replace(/\*\*/g, '').trim()}</p>
                            </div>
                        ))}
                    </div>
                ) : (
                    <p className="text-gray-500">Chưa có kịch bản nào được tạo.</p>
                )}
            </div>
        </>
    );
};

export default ScriptGenerator;