import React from 'react';
import { TabName } from './types';

export const TABS = [
  { id: TabName.PromptOptimizer, label: 'Tối ưu Prompt' },
  { id: TabName.ScriptGenerator, label: 'Tạo kịch bản AI' },
  { id: TabName.TextToSpeech, label: 'Studio TTS' },
];

export const TTS_VOICES = [
    { id: 'Kore', name: 'Kore (Nam, Bình tĩnh)' },
    { id: 'Puck', name: 'Puck (Nam, Năng động)' },
    { id: 'Charon', name: 'Charon (Nam, Giọng trầm)' },
    { id: 'Fenrir', name: 'Fenrir (Nam, Uy quyền)' },
    { id: 'Zephyr', name: 'Zephyr (Nữ, Dịu dàng)' },
];

export const PROMPT_TEMPLATES = [
    {
        name: 'Ảnh Điện ảnh',
        prompt: 'cinematic photo of a [SUBJECT], 4k, high resolution, detailed, professional color grading, dramatic lighting',
    },
    {
        name: 'Nhân vật Anime',
        prompt: 'A vibrant anime-style portrait of a [CHARACTER] with [HAIR_COLOR] hair and [EYE_COLOR] eyes, wearing [CLOTHING]. Background is a bustling futuristic city. Art by Makoto Shinkai, studio ghibli inspired, 4k, key visual, beautiful lighting.',
    },
    {
        name: 'Kết xuất 3D',
        prompt: 'A hyper-realistic 3D render of a [OBJECT], octane render, trending on artstation, 8k, photorealistic, intricate detail, ambient occlusion.',
    },
    {
        name: 'Thiết kế Logo',
        prompt: 'Minimalist vector logo of a [SUBJECT], flat design, vibrant accent color, on a clean white background, Behance HD, by Paul Rand.',
    },
];

export const TARGET_MODELS = ['ChatGPT', 'Midjourney', 'DALL-E 3', 'Claude 3', 'Runway'];
export const SCRIPT_TONES = ['Cung cấp thông tin', 'Hài hước', 'Truyền cảm hứng', 'Thân mật', 'Trang trọng'];
export const SCRIPT_DURATIONS = [
    'Dưới 15s (TikTok)', 
    '30-60s (Shorts/Reels)', 
    '1-3 phút (Podcast Clip)',
    '3-5 phút (Video YouTube)',
    '5-10 phút (Video YouTube)',
    'Trên 10 phút (Video dài)'
];

export const DownloadIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
    </svg>
);

export const CopyIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
        <path d="M7 9a2 2 0 012-2h6a2 2 0 012 2v6a2 2 0 01-2 2H9a2 2 0 01-2-2V9z" />
        <path d="M5 3a2 2 0 00-2 2v6a2 2 0 002 2V5h6a2 2 0 00-2-2H5z" />
    </svg>
);

export const PlayIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
    </svg>
);

export const SparklesIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
    </svg>
);

export const TrashIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
    </svg>
);