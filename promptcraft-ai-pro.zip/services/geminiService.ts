import { GoogleGenAI, Modality } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const generateScript = async (idea: string, duration: string, tone: string, audience: string): Promise<string> => {
    const prompt = `
        Bạn là một chuyên gia viết kịch bản cho nội dung mạng xã hội. Nhiệm vụ của bạn là tạo ra một kịch bản video hấp dẫn bằng tiếng Việt.
        
        **Hướng dẫn:**
        1.  **Phân tích đầu vào:** Xem xét cẩn thận ý tưởng, thời lượng mong muốn, tông giọng và đối tượng khán giả.
        2.  **Cấu trúc kịch bản:** Kịch bản phải có ba phần riêng biệt:
            -   **Hook (0-5 giây):** Một câu mở đầu lôi cuốn để thu hút sự chú ý của người xem ngay lập tức.
            -   **Body (Nội dung chính):** Nội dung chính, truyền tải thông điệp cốt lõi một cách hấp dẫn.
            -   **CTA (Kêu gọi hành động):** Lời kêu gọi hành động rõ ràng và súc tích ở cuối.
        3.  **Nội dung:** Viết lời thoại tự nhiên, đàm thoại và hấp dẫn. Đảm bảo nội dung phù hợp với thời lượng và đối tượng đã chỉ định.
        4.  **Định dạng & Phân cảnh:** Sử dụng Markdown để định dạng. Chia toàn bộ kịch bản thành các cảnh được đánh số thứ tự (ví dụ: '### Cảnh 1', '### Cảnh 2'). **Mỗi cảnh phải có thời lượng ước tính từ 1 đến 8 giây.** Phân bổ các cảnh này trong các phần Hook, Body và CTA.

        **Chi tiết kịch bản:**
        -   **Ý tưởng:** "${idea}"
        -   **Thời lượng:** "${duration}"
        -   **Tông giọng:** "${tone}"
        -   **Đối tượng khán giả:** "${audience}"

        Bây giờ, hãy tạo kịch bản.
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        return response.text;
    } catch (error) {
        console.error("Error generating script:", error);
        return "Xin lỗi, tôi không thể tạo kịch bản vào lúc này. Vui lòng thử lại.";
    }
};

export const optimizePrompt = async (originalPrompt: string, targetModel: string): Promise<string> => {
    const prompt = `
        Bạn là một chuyên gia Kỹ thuật Prompt AI. Nhiệm vụ của bạn là phân tích và viết lại câu lệnh của người dùng để nó hiệu quả hơn đáng kể cho một mô hình AI mục tiêu cụ thể.

        **Hướng dẫn:**
        1.  **Phân tích câu lệnh gốc:** Xác định chủ đề và ý định cốt lõi.
        2.  **Làm giàu chi tiết:** Thêm các từ khóa mô tả, cụ thể để tăng cường sự rõ ràng và hướng dẫn AI. Xem xét các yếu tố như phong cách, ánh sáng, bố cục, độ phân giải và ảnh hưởng nghệ thuật.
        3.  **Cấu trúc cho mô hình mục tiêu:** Điều chỉnh cú pháp và cách sử dụng từ khóa cho mô hình AI được chỉ định ("${targetModel}"). Đối với các mô hình hình ảnh, hãy sử dụng các thẻ mô tả được phân tách bằng dấu phẩy. Đối với các mô hình văn bản, hãy cung cấp ngữ cảnh và hướng dẫn nhập vai rõ ràng.
        4.  **Đầu ra:** CHỈ cung cấp câu lệnh đã được tối ưu hóa. Không bao gồm bất kỳ lời giải thích, lời xin lỗi hoặc cụm từ giới thiệu nào.

        **Chi tiết câu lệnh:**
        -   **Câu lệnh gốc:** "${originalPrompt}"
        -   **Mô hình AI mục tiêu:** "${targetModel}"

        Câu lệnh đã tối ưu:
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-pro',
            contents: prompt,
        });
        return response.text;
    } catch (error) {
        console.error("Error optimizing prompt:", error);
        return "Xin lỗi, tôi không thể tối ưu hóa câu lệnh ngay bây giờ. Vui lòng kiểm tra lại đầu vào của bạn.";
    }
};

export const generateSpeech = async (text: string, voice: string): Promise<string> => {
    try {
         const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-tts",
            contents: [{ parts: [{ text: text }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: voice },
                    },
                },
            },
        });

        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (!base64Audio) {
            throw new Error("No audio data returned from API.");
        }
        return base64Audio;
    } catch (error) {
        console.error("Error generating speech:", error);
        throw new Error("Tạo giọng nói thất bại. Vui lòng thử lại.");
    }
};