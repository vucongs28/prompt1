import React, { useState } from 'react';
import Header from './components/Header';
import Tabs from './components/Tabs';
import ScriptGenerator from './components/ScriptGenerator';
import PromptOptimizer from './components/PromptOptimizer';
import TextToSpeechStudio from './components/TextToSpeechStudio';
import { TabName } from './types';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabName>(TabName.PromptOptimizer);

  const renderContent = () => {
    switch (activeTab) {
      case TabName.ScriptGenerator:
        return <ScriptGenerator />;
      case TabName.PromptOptimizer:
        return <PromptOptimizer />;
      case TabName.TextToSpeech:
        return <TextToSpeechStudio />;
      default:
        return <PromptOptimizer />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white font-sans">
      <div className="container mx-auto px-4 py-8">
        <Header />
        <Tabs activeTab={activeTab} setActiveTab={setActiveTab} />
        <main className="mt-8 bg-gray-800 rounded-xl shadow-2xl p-6 md:p-8">
          {renderContent()}
        </main>
      </div>
    </div>
  );
};

export default App;