
export enum TabName {
  ScriptGenerator = 'ScriptGenerator',
  PromptOptimizer = 'PromptOptimizer',
  TextToSpeech = 'TextToSpeech',
}
